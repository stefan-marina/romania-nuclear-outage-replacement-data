import argparse
import csv
import json
import os
import platform
import shutil
import sys
import time
import urllib.request
from datetime import datetime

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Prompts & Results", "llm_experiments")
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
NUM_CTX = 8192
BASIC = ["planner_basic.txt", "planner_informed.txt"]
ALL = BASIC + ["planner_reasoning.txt"]

ROUNDS = {
    1: {
        "num_predict": 4096,
        "plan": {
            "llama3.1:8b": {"scenarios": True, "planner": BASIC},
            "qwen2.5:7b": {"scenarios": True, "planner": BASIC},
        },
    },
    2: {
        "num_predict": 8192,
        "plan": {
            "qwen2.5:14b": {"scenarios": True, "planner": ALL},
            "phi4:14b": {"scenarios": True, "planner": ALL},
            "deepseek-r1:14b": {"scenarios": True, "planner": ALL},
            "llama3.1:8b": {"scenarios": False, "planner": ["planner_reasoning.txt"]},
            "qwen2.5:7b": {"scenarios": False, "planner": ["planner_reasoning.txt"]},
        },
    },
}
THINKING = {"deepseek-r1:14b"}

SCENARIO_SCHEMA = {
    "type": "object",
    "properties": {"scenarios": {"type": "array", "items": {
        "type": "object",
        "properties": {
            "year": {"type": "integer"},
            "name": {"type": "string"},
            "nuclear_available_mw": {"type": "number"},
            "outage_months": {"type": "array", "items": {"type": "integer"}},
            "hydro_change_pct": {"type": "number"},
            "evening_demand_change_pct": {"type": "number"},
            "solar_resource_change_pct": {"type": "number"},
            "wind_resource_change_pct": {"type": "number"},
            "rationale": {"type": "string"},
        },
        "required": ["year", "name", "nuclear_available_mw", "outage_months", "hydro_change_pct",
                     "evening_demand_change_pct", "solar_resource_change_pct", "wind_resource_change_pct",
                     "rationale"],
    }}},
    "required": ["scenarios"],
}

PLANNER_SCHEMA = {
    "type": "object",
    "properties": {
        "pv_mw": {"type": "number"},
        "wind_mw": {"type": "number"},
        "battery_power_mw": {"type": "number"},
        "battery_energy_mwh": {"type": "number"},
        "expected_cost_eur_per_mwh": {"type": "number"},
        "reasoning": {"type": "string"},
    },
    "required": ["pv_mw", "wind_mw", "battery_power_mw", "battery_energy_mwh", "expected_cost_eur_per_mwh",
                 "reasoning"],
}


def call(path, payload=None, timeout=1800):
    req = urllib.request.Request(
        OLLAMA_URL.rstrip("/") + path,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="GET" if payload is None else "POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def read_prompt(name, n=""):
    with open(os.path.join(HERE, "prompts", "context.txt"), encoding="utf-8") as fh:
        context = fh.read()
    with open(os.path.join(HERE, "prompts", name), encoding="utf-8") as fh:
        text = fh.read()
    return text.replace("{CONTEXT}", context).replace("{N}", str(n))


def ask(model, text, schema, temperature, seed, num_predict, log, tag):
    for attempt in range(3):
        s = seed + 1000 * attempt
        payload = {
            "model": model,
            "stream": False,
            "format": schema,
            "messages": [{"role": "user", "content": text}],
            "options": {"temperature": temperature, "seed": s, "num_ctx": NUM_CTX, "num_predict": num_predict},
        }
        if model in THINKING:
            payload["think"] = True
        t0 = time.time()
        reply, content, thinking, parsed, error = {}, "", "", None, ""
        try:
            reply = call("/api/chat", payload)
            content = reply["message"]["content"]
            thinking = reply["message"].get("thinking", "")
            parsed = json.loads(content)
        except Exception as exc:
            error = repr(exc)
        record = {
            "thinking": thinking, "tag": tag, "model": model, "temperature": temperature, "seed": s,
            "attempt": attempt, "ok": parsed is not None, "error": error, "seconds": round(time.time() - t0, 1),
            "content": content, "eval_count": reply.get("eval_count"),
            "prompt_eval_count": reply.get("prompt_eval_count"),
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        log.write(json.dumps(record, ensure_ascii=False) + "\n")
        log.flush()
        print(f"{tag:<28} {model:<16} seed={s:<5} {'ok' if parsed is not None else 'failed'} {record['seconds']} s")
        if parsed is not None:
            return parsed, s
    return None, None


def write_csv(path, rows):
    if not rows:
        return
    keys = sorted({k for r in rows for k in r})
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def run(round_no, test=False):
    cfg = ROUNDS[round_no]
    plan = dict(cfg["plan"])
    try:
        version = call("/api/version").get("version")
        available = {m["name"] for m in call("/api/tags")["models"]}
    except Exception as exc:
        sys.exit(f"cannot reach Ollama at {OLLAMA_URL}: {exc}")
    for model in list(plan):
        if model not in available:
            print("pulling", model)
            try:
                call("/api/pull", {"model": model, "stream": False}, timeout=7200)
            except Exception as exc:
                print("skipping", model, exc)
                plan.pop(model)
    tags = {m["name"]: m for m in call("/api/tags")["models"]}

    out = os.path.join(HERE, f"round{round_no}_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    os.makedirs(out)
    shutil.copytree(os.path.join(HERE, "prompts"), os.path.join(out, "prompts"))
    meta = {
        "ollama_url": OLLAMA_URL, "ollama_version": version, "python": sys.version,
        "platform": platform.platform(), "start": datetime.now().isoformat(timespec="seconds"),
        "num_ctx": NUM_CTX, "test_run": test, "models": {},
    }
    for model in plan:
        info = tags.get(model, {})
        try:
            show = call("/api/show", {"model": model})
        except Exception:
            show = {}
        meta["models"][model] = {
            "digest": info.get("digest"), "size": info.get("size"), "details": info.get("details"),
            "modified_at": info.get("modified_at"), "parameters": show.get("parameters"),
        }

    scenarios, proposals = [], []
    runs = [(0.0, 0)] + [(0.7, i) for i in range(1, 10)]
    if test:
        runs = runs[:1]
    with open(os.path.join(out, "raw_responses.jsonl"), "w", encoding="utf-8") as log:
        for model, todo in plan.items():
            seeds = ([101] if test else [101, 102]) if todo["scenarios"] else []
            for k, seed in enumerate(seeds):
                text = read_prompt("scenarios.txt", n=3 if test else 10)
                res, s = ask(model, text, SCENARIO_SCHEMA, 0.7, seed, cfg["num_predict"], log, f"A_scenarios_call{k + 1}")
                for j, sc in enumerate((res or {}).get("scenarios", [])):
                    row = {"model": model, "call": k + 1, "seed": s, "idx": j + 1}
                    row.update({key: json.dumps(v) if isinstance(v, list) else v for key, v in sc.items()})
                    scenarios.append(row)
            prompts = todo["planner"][-1:] if test else todo["planner"]
            for name in prompts:
                label = name.replace(".txt", "")
                for temperature, seed in runs:
                    res, s = ask(model, read_prompt(name), PLANNER_SCHEMA, temperature, seed, cfg["num_predict"],
                                 log, "B_" + label)
                    if res:
                        proposals.append({"model": model, "prompt": label, "temperature": temperature, "seed": s,
                                          **res})

    write_csv(os.path.join(out, "scenarios.csv"), scenarios)
    write_csv(os.path.join(out, "planner.csv"), proposals)
    meta["end"] = datetime.now().isoformat(timespec="seconds")
    meta["n_scenarios"], meta["n_planner"] = len(scenarios), len(proposals)
    with open(os.path.join(out, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=1)
    print(f"{len(scenarios)} scenarios, {len(proposals)} proposals -> {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--round", type=int, choices=[1, 2], required=True)
    ap.add_argument("--test", action="store_true")
    args = ap.parse_args()
    run(args.round, args.test)

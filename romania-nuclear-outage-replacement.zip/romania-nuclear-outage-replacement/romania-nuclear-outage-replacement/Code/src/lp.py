import numpy as np
import scipy.sparse as sp
from scipy.optimize import linprog

USD_TO_EUR = 1 / 1.082
THROUGHPUT_PENALTY = 0.01


def crf(rate, years):
    return rate * (1 + rate) ** years / ((1 + rate) ** years - 1)


def annual_costs(wacc=0.07, capex_mult=1.0, bess_mult=1.0, energy_share=0.7):
    pv = 691 * USD_TO_EUR * 1e3 * capex_mult
    wind = 1041 * USD_TO_EUR * 1e3 * capex_mult
    bess = 192 * USD_TO_EUR * 1e3 * bess_mult
    energy = energy_share * bess
    power = (1 - energy_share) * bess * 4
    return {
        "S": pv * (crf(wacc, 30) + 0.015),
        "W": wind * (crf(wacc, 25) + 0.025),
        "E": energy * (crf(wacc, 15) + 0.025),
        "P": power * (crf(wacc, 15) + 0.025),
    }


def solve(demand, pv_profile, wind_profile, mode="hard", import_cap=0.0, eps=None, price=None,
          costs=None, fix=None, allow_wind=True, soc=(0.1, 0.9), rte=0.88):
    T = len(demand)
    costs = costs or annual_costs()
    fix = fix or {}
    eta = np.sqrt(rte)
    share = T / 8760

    iS, iW, iP, iE = 0, 1, 2, 3
    ch, dis, lvl, ext, spill = [4 + k * T for k in range(5)]
    n = 4 + 5 * T

    c = np.zeros(n)
    c[[iS, iW, iP, iE]] = [costs["S"] * share, costs["W"] * share, costs["P"] * share, costs["E"] * share]
    if mode == "econ":
        c[ext:ext + T] = price
    c[ch:ch + T] = THROUGHPUT_PENALTY
    c[dis:dis + T] = THROUGHPUT_PENALTY

    I = sp.eye(T)
    Z = sp.csr_matrix((T, T))
    hours = np.arange(T)

    balance = sp.hstack([
        sp.csr_matrix(pv_profile.reshape(-1, 1)), sp.csr_matrix(wind_profile.reshape(-1, 1)),
        sp.csr_matrix((T, 2)), -I, I, Z, I, -I,
    ])
    lag = sp.csr_matrix((np.ones(T), (hours, (hours - 1) % T)), shape=(T, T))
    storage = sp.hstack([sp.csr_matrix((T, 4)), -eta * I, (1 / eta) * I, I - lag, sp.csr_matrix((T, 2 * T))])
    A_eq = sp.vstack([balance, storage]).tocsr()
    b_eq = np.r_[demand, np.zeros(T)]

    col_p = sp.csr_matrix((np.ones(T), (hours, np.full(T, iP))), shape=(T, 4))
    col_e = sp.csr_matrix((np.ones(T), (hours, np.full(T, iE))), shape=(T, 4))
    blocks = [
        sp.hstack([-col_p, I, Z, Z, Z, Z]),
        sp.hstack([-col_p, Z, I, Z, Z, Z]),
        sp.hstack([-soc[1] * col_e, Z, Z, I, Z, Z]),
        sp.hstack([soc[0] * col_e, Z, Z, -I, Z, Z]),
    ]
    rhs = [np.zeros(T)] * 4
    if mode == "energy":
        row = np.zeros(n)
        row[ext:ext + T] = 1
        blocks.append(sp.csr_matrix(row))
        rhs.append(np.array([eps * np.clip(demand, 0, None).sum()]))
    A_ub = sp.vstack(blocks).tocsr()
    b_ub = np.concatenate(rhs)

    bounds = [(0, None)] * n
    for key, idx in (("S", iS), ("W", iW), ("P", iP), ("E", iE)):
        if fix.get(key) is not None:
            bounds[idx] = (fix[key], fix[key])
    if not allow_wind:
        bounds[iW] = (0, 0)
    if mode == "hard":
        bounds[ext:ext + T] = [(0, import_cap)] * T
    elif mode == "econ":
        bounds[ext:ext + T] = [(0, max(d, 0.0)) for d in demand]

    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    if res.status != 0:
        return {"status": res.message}

    v = res.x
    x = v[ext:ext + T]
    positive = np.clip(demand, 0, None).sum()
    return {
        "status": "ok",
        "S": v[iS], "W": v[iW], "P": v[iP], "E": v[iE],
        "cost_period": res.fun,
        "capex_annual": sum(v[i] * costs[k] for i, k in ((iS, "S"), (iW, "W"), (iP, "P"), (iE, "E"))),
        "ext": x.sum(),
        "spill": v[spill:spill + T].sum(),
        "dis": v[dis:dis + T].sum(),
        "chg": v[ch:ch + T].sum(),
        "coverage": 1 - x.sum() / positive if positive > 0 else np.nan,
        "D_pos": positive,
        "ext_hours": int((x > 1).sum()),
        "x": x, "q": v[spill:spill + T], "c": v[ch:ch + T], "d": v[dis:dis + T],
    }

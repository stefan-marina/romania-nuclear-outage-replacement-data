import argparse
import glob
import zipfile

import pandas as pd

from settings import DATA

RENAME = {
    "Biomass": "biomass",
    "Energy storage": "storage",
    "Fossil Brown coal/Lignite": "lignite",
    "Fossil Gas": "gas",
    "Fossil Hard coal": "coal",
    "Hydro Run-of-river and pondage": "hydro_ror",
    "Hydro Water Reservoir": "hydro_res",
    "Nuclear": "nuclear",
    "Solar": "solar",
    "Wind Onshore": "wind",
}


def romanian_rows(pattern):
    parts = []
    for path in sorted(glob.glob(pattern)):
        with zipfile.ZipFile(path) as zf:
            name = next(n for n in zf.namelist() if n.endswith(".csv"))
            for chunk in pd.read_csv(zf.open(name), sep="\t", chunksize=500_000):
                parts.append(chunk[chunk["AreaMapCode"] == "RO"])
        print(path)
    df = pd.concat(parts)
    df["t"] = pd.to_datetime(df["DateTime(UTC)"])
    return df


def build(gen_dir, load_dir, ember_csv):
    gen = romanian_rows(gen_dir + "/*AggregatedGenerationPerType*.zip")
    load = romanian_rows(load_dir + "/*ActualTotalLoad*.zip")
    G = gen.pivot_table(index="t", columns="ProductionType", values="ActualGenerationOutput[MW]", aggfunc="mean")
    L = load.set_index("t")["TotalLoad[MW]"]

    idx = pd.date_range("2025-01-01 00:00", "2026-10-25 21:45", freq="15min")
    G, L = G.reindex(idx), L.reindex(idx)
    G["Energy storage"] = G["Energy storage"].fillna(0)
    G = G.interpolate(limit=4, limit_area="inside")
    L = L.interpolate(limit=4, limit_area="inside")

    H = G.resample("h").mean()
    H["load"] = L.resample("h").mean()
    H.index = H.index.tz_localize("UTC")
    H = H.rename(columns=RENAME)
    H["gen"] = H[list(RENAME.values())].sum(axis=1)
    H["net_import"] = H["load"] - H["gen"]

    prices = pd.read_csv(ember_csv)
    prices["t"] = pd.to_datetime(prices["Datetime (UTC)"]).dt.tz_localize("UTC")
    H["price"] = prices.set_index("t")["Price (EUR/MWhe)"].reindex(H.index)
    H["local"] = H.index.tz_convert("Europe/Bucharest")
    H.to_csv(DATA / "ro_hourly_2025_2026.csv")
    print(len(H), "hours written")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("generation_dir")
    ap.add_argument("load_dir")
    ap.add_argument("ember_csv")
    args = ap.parse_args()
    build(args.generation_dir, args.load_dir, args.ember_csv)

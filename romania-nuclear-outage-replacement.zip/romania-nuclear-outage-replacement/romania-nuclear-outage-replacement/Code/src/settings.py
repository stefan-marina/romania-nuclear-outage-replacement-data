from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "Datasets"
RESULTS = ROOT / "Prompts & Results" / "llm_evaluation"
FIGURES = ROOT / "Figures"
LLM = ROOT / "Prompts & Results" / "llm_experiments"
ROUND1 = LLM / "round1_20261027"
ROUND2 = LLM / "round2_20261028"

NUCLEAR_MW = 1219.0
WIND_CAPACITY = {"2025": 3027.0, "2026": 3068.0}
PV_ANCHOR_MW = 3500.0
SITE_LATITUDE = 45.9
PANEL_TILT = 30.0
SEASON = (5, 9)
EVENING = (19, 22)

RESULTS.mkdir(exist_ok=True)
FIGURES.mkdir(exist_ok=True)

import json

import numpy as np
import pandas as pd

from lp import solve, annual_costs
from profiles import load_hourly, season
from settings import RESULTS, ROUND1, ROUND2, NUCLEAR_MW, EVENING

COLUMNS = ["pv_mw", "wind_mw", "battery_power_mw", "battery_energy_mwh"]
FREE = {"S": 0, "W": 0, "P": 0, "E": 0}


class Case:
    def __init__(self):
        H = load_hourly()[0]
        self.g = season(H, "2026")
        self.T = len(self.g)
        self.share = self.T / 8760
        self.costs = annual_costs()
        self.lost = np.clip(NUCLEAR_MW - self.g["nuclear"].values, 0, None)
        self.s = self.g["s"].values
        self.w = self.g["w"].values
        self.hydro = (self.g["hydro_res"] + self.g["hydro_ror"]).values
        self.load = self.g["load"].values
        self.evening = self.g["hour"].between(*EVENING).values
        self.month = self.g["mon"].values

    def annual_cost(self, S, W, P, E):
        c = self.costs
        return c["S"] * S + c["W"] * W + c["P"] * P + c["E"] * E

    def simulate(self, S, W, P, E):
        fixed = {"S": S, "W": W, "P": P, "E": E}
        return solve(self.lost, self.s, self.w, mode="econ", price=np.ones(self.T), costs=FREE, fix=fixed)

    def requirement(self, nuclear, months, hydro, evening, solar, wind):
        months = [m for m in months if 5 <= m <= 9]
        hit = np.isin(self.month, months) if months else np.ones(self.T, bool)
        nuc = np.where(hit, min(max(nuclear, 0), NUCLEAR_MW), NUCLEAR_MW)
        ds = np.where(hit, solar / 100, 0.0)
        dw = np.where(hit, wind / 100, 0.0)
        need = (NUCLEAR_MW - nuc) + hit * (-hydro / 100 * self.hydro + evening / 100 * self.load * self.evening)
        need = need - ds * self.g["solar"].values - dw * self.g["wind"].values
        return np.clip(need, 0, None), ds, dw, (len(months) if months else 5)

    def size(self, need, ds, dw):
        if need.sum() <= 1:
            return {}
        r = solve(need, self.s * (1 + ds), self.w * (1 + dw), mode="energy", eps=0.05)
        return dict(
            peak=need.max(), S=r["S"], W=r["W"], P=r["P"], E=r["E"],
            dur=r["E"] / r["P"] if r["P"] > 1 else np.nan,
            capex_annual_m=r["capex_annual"] / 1e6,
            cost_per_mwh=r["capex_annual"] * self.share / (r["D_pos"] - r["ext"]),
        )


def frontier(case):
    rows = []
    for cov in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]:
        r = solve(case.lost, case.s, case.w, mode="energy", eps=1 - cov)
        rows.append(dict(cov=cov, cost_m=r["capex_annual"] / 1e6, S=r["S"], W=r["W"], P=r["P"], E=r["E"]))
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "frontier_coverage.csv", index=False)
    return df


def unit_flag(S, W, P, E):
    if 0 < max(S, W, P, E) < 50 or (0 < E < 5 and P > 50):
        return "unit"
    return "extreme" if E > 100000 else ""


def planner(case, front):
    xs = [0] + front["cov"].tolist()
    ys = [0] + front["cost_m"].tolist()
    rows = []
    for tag, folder in (("v1", ROUND1), ("v2", ROUND2)):
        for _, p in pd.read_csv(folder / "planner.csv").iterrows():
            S, W, P, E = [max(0.0, float(p[c])) for c in COLUMNS]
            r = case.simulate(S, W, P, E)
            served = r["D_pos"] - r["ext"]
            cost = case.annual_cost(S, W, P, E)
            cheapest = np.interp(r["coverage"], xs, ys)
            rows.append(dict(
                round=tag, model=p["model"], prompt=p["prompt"], temperature=p["temperature"], seed=p["seed"],
                S=S, W=W, P=P, E=E, coverage=r["coverage"], cost_annual_m=cost / 1e6,
                cost_per_mwh=cost * case.share / served if served > 0 else np.nan,
                claimed=p["expected_cost_eur_per_mwh"], min_cost_same_cov_m=cheapest,
                cost_ratio=cost / 1e6 / cheapest if cheapest > 0 else np.nan, flag=unit_flag(S, W, P, E),
            ))
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "llm_planner_eval_all.csv", index=False)
    return df


def summary_table(df):
    df = df.copy()
    df["flag"] = df["flag"].fillna("")
    df["dur"] = np.where(df["P"] > 0, df["E"] / df["P"].replace(0, np.nan), np.nan)
    valid = (df["flag"] == "") & (df["coverage"] > 0.1)
    ratio = df.loc[valid, "cost_ratio"]
    print(f"cost ratio median {ratio.median():.2f}, IQR {ratio.quantile(0.25):.2f}-{ratio.quantile(0.75):.2f}, "
          f"n={len(ratio)}")
    order = ["llama3.1:8b", "qwen2.5:7b", "qwen2.5:14b", "phi4:14b", "deepseek-r1:14b"]
    out = []
    for model in order:
        for prompt in ["planner_basic", "planner_informed", "planner_reasoning"]:
            g = df[(df["model"] == model) & (df["prompt"] == prompt)]
            if g.empty:
                continue
            out.append(dict(
                model=model, prompt=prompt, n=len(g),
                S=g["S"].median() / 1000, W=g["W"].median() / 1000, P=g["P"].median() / 1000,
                E=g["E"].median() / 1000, dur=g["dur"].median(),
                cov=100 * g["coverage"].median(), covmax=100 * g["coverage"].max(),
                flag=int((g["flag"] != "").sum()),
                quoted=g["claimed"].median(), ratio=g.loc[valid[g.index], "cost_ratio"].median(),
            ))
    pd.DataFrame(out).to_csv(RESULTS / "table7_llm_planner.csv", index=False)


def llm_scenarios(case, folder, outfile):
    rows = []
    for _, r in pd.read_csv(folder / "scenarios.csv").iterrows():
        months = json.loads(r["outage_months"]) if isinstance(r["outage_months"], str) else []
        sc = dict(
            nuclear=float(r["nuclear_available_mw"]), months=months, hydro=float(r["hydro_change_pct"]),
            evening=float(r["evening_demand_change_pct"]), solar=float(r["solar_resource_change_pct"]),
            wind=float(r["wind_resource_change_pct"]),
        )
        need, ds, dw, k = case.requirement(**sc)
        rows.append(dict(model=r["model"], call=r["call"], idx=r["idx"], name=r["name"], year=r["year"],
                         **{**sc, "months": json.dumps(sc["months"])}, n_months=k,
                         D_twh=need.sum() / 1e6, **case.size(need, ds, dw)))
    pd.DataFrame(rows).to_csv(RESULTS / outfile, index=False)


def random_scenarios(case, n=40, seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n):
        k = rng.integers(1, 6)
        start = rng.integers(5, 10 - k + 1)
        sc = dict(
            nuclear=float(rng.uniform(0, 1300)), months=list(range(int(start), int(start + k))),
            hydro=float(rng.uniform(-60, 30)), evening=float(rng.uniform(-10, 20)),
            solar=float(rng.uniform(-25, 15)), wind=float(rng.uniform(-30, 30)),
        )
        need, ds, dw, k = case.requirement(**sc)
        rows.append(dict(idx=i + 1, **{**sc, "months": json.dumps(sc["months"])}, n_months=k,
                         D_twh=need.sum() / 1e6, **case.size(need, ds, dw)))
    pd.DataFrame(rows).to_csv(RESULTS / "random_scenarios_eval.csv", index=False)


if __name__ == "__main__":
    case = Case()
    front = frontier(case)
    summary_table(planner(case, front))
    llm_scenarios(case, ROUND1, "llm_scenarios_eval.csv")
    llm_scenarios(case, ROUND2, "llm_scenarios_eval_v2.csv")
    random_scenarios(case)
    print("results written to", RESULTS)

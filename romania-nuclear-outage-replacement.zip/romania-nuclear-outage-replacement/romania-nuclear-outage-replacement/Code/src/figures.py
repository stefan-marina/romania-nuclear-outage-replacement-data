import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

from profiles import load_hourly
from settings import DATA, RESULTS, FIGURES

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9.5, "axes.titleweight": "bold",
    "figure.dpi": 200, "axes.spines.top": False, "axes.spines.right": False,
})

INK, MUTED = "#333333", "#8a8a8a"
MODELS = ["llama3.1:8b", "qwen2.5:7b", "qwen2.5:14b", "phi4:14b", "deepseek-r1:14b"]
MODEL_COLOR = dict(zip(MODELS, ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]))
MODEL_LABEL = dict(zip(MODELS, ["Llama 3.1 8B", "Qwen 2.5 7B", "Qwen 2.5 14B", "Phi-4 14B", "DeepSeek-R1 14B"]))
PROMPTS = ["planner_basic", "planner_informed", "planner_reasoning"]
MARKER = dict(zip(PROMPTS, ["o", "^", "s"]))
PROMPT_LABEL = dict(zip(PROMPTS, ["basic", "informed", "reasoning"]))


def save(name, dpi=None):
    plt.tight_layout()
    plt.savefig(FIGURES / name, bbox_inches="tight", dpi=dpi)
    plt.close()


def grid(ax, axis="both"):
    ax.grid(ls=":", alpha=0.4, axis=axis)


def system_figure(H):
    monthly = H.groupby("ym")[["nuclear", "gas", "net_import", "solar"]].mean()
    evening = H[H["hour"].between(19, 22)]
    ev_import = evening.groupby("ym")["net_import"].mean()
    ev_price = evening.groupby("ym")["price"].mean()
    labels = [pd.Timestamp(m + "-01").strftime("%b\n%y") if m[5:] in ("01", "04", "07", "10") else ""
              for m in monthly.index]
    x = np.arange(len(monthly))

    fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.2))
    series = [("nuclear", "Nuclear", "#7a6ba8", "-"), ("gas", "Gas", "#d62728", "-"),
              ("net_import", "Net import", "#333", "--"), ("solar", "Solar (metered)", "#f0a830", "-")]
    for col, label, color, ls in series:
        ax[0].plot(x, monthly[col], marker="o", ms=2.5, lw=1.6, color=color, ls=ls, label=label)
    ax[0].axvspan(15.5, 21.5, color="#eee", zorder=0)
    ax[0].set_xticks(x)
    ax[0].set_xticklabels(labels)
    ax[0].set_ylabel("Monthly mean (MW)")
    ax[0].legend(fontsize=7, ncol=2)
    ax[0].set_title("(a) Supply mix, Jan 2025 – Oct 2026")
    grid(ax[0])

    colors = ["#9ab8d4" if m < "2026-05" else "#1f3c5a" for m in monthly.index]
    ax[1].bar(x, ev_import.values, color=colors)
    ax[1].set_xticks(x)
    ax[1].set_xticklabels(labels)
    ax[1].set_ylabel("Net import, 19:00–23:00 (MW)")
    twin = ax[1].twinx()
    twin.plot(x, ev_price.values, "o-", color="#c0504d", ms=2.5, lw=1.4)
    twin.set_ylabel("Evening price (EUR/MWh)", color="#c0504d")
    twin.spines["right"].set_visible(True)
    ax[1].set_title("(b) Evening import dependence and price")
    ax[1].axvspan(15.5, 21.5, color="#eee", zorder=0)
    save("fig3_system.png")


def dispatch_figure(dp):
    week = dp[(dp["t"] >= "2026-08-17") & (dp["t"] < "2026-08-24")].reset_index(drop=True)
    need = week["D"].values
    wind = np.minimum(week["wind"], need)
    pv = np.minimum(week["pv"], need - wind)
    dis = np.minimum(week["d"], need - wind - pv)
    x = np.arange(len(week))

    fig, ax = plt.subplots(figsize=(9.2, 3.1))
    ax.stackplot(x, wind, pv, dis, week["x"], colors=["#7fb3d5", "#f6c45f", "#2e8b57", "#c0504d"],
                 labels=["Added wind (used)", "Added PV (used)", "Battery discharge", "Residual import / gas"])
    ax.plot(x, week["D"], color="k", lw=1.4, label="Lost nuclear output")
    ax.fill_between(x, 0, -week["c"], color="#a9d8b8", label="Battery charging (negative)")
    ax.fill_between(x, -week["c"], -week["c"] - week["q"], color="#dddddd", label="Surplus not stored (negative)")
    ax.set_xticks(range(0, len(week), 24))
    ax.set_xticklabels([t.strftime("%a %d %b") for t in week["t"].iloc[::24]])
    ax.set_ylabel("MW")
    ax.legend(fontsize=6.5, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.12), frameon=False)
    ax.set_ylim(-3200, 1700)
    ax.set_title("Optimised 95% portfolio, 17–23 August 2026 (both Cernavodă units offline)")
    grid(ax)
    save("fig4_dispatch.png")


def frontier_figure():
    net = pd.read_csv(RESULTS / "net_cost.csv")
    flat = pd.read_csv(RESULTS / "const_weather_price.csv", dtype={"year": str, "eps": str})

    fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.2))
    for wind, color, label in ((True, "#1f77b4", "PV + wind + storage"), (False, "#f0a830", "PV + storage only")):
        g = net[net["wind"] == wind]
        ax[0].plot(100 * g["coverage"], g["capex_m"], "o-", color=color, ms=3, label=label)
        ax[1].plot(100 * g["coverage"], g["net_m"], "o-", color=color, ms=3, label=label + " (2026 outage profile)")
    for year, color in (("2025", "#888"), ("2026", "#1f3c5a")):
        g = flat[(flat["year"] == year) & (flat["eps"] != "econ")]
        ax[1].plot(100 * g["coverage"].astype(float), g["net_m"], "s:", color=color, ms=3, lw=1.1,
                   label=f"Full 1,219 MW outage, {year} weather & prices")

    ax[0].set_xlabel("Share of lost nuclear energy replaced (%)")
    ax[0].set_ylabel("Annualised cost, May–Sep (EUR m)")
    ax[0].set_title("(a) Cost of replacement, 2026")
    ax[0].legend(fontsize=7)
    grid(ax[0])
    ax[1].axhline(0, color="k", lw=0.7)
    ax[1].set_xlabel("Share of lost nuclear energy replaced (%)")
    ax[1].set_ylabel("Cost minus avoided purchases (EUR m)")
    ax[1].set_title("(b) Net cost at day-ahead prices")
    grid(ax[1])
    ax[1].legend(fontsize=6.3, loc="upper left")
    save("fig5_frontier.png")


def sensitivity_figure(res):
    trade = res[res["tag"] == "E_tradeoff"]
    sens = res[res["tag"] == "F_sens"].set_index("case")["cost_per_mwh"]
    base = res[(res["tag"] == "A_nuclear") & (res["eps"] == 0.05)]["cost_per_mwh"].iloc[0]

    fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.1))
    ax[0].plot(trade["S"] / 1000, trade["W"] / 1000, "o-", color="#1f77b4", label="Added wind (GW)")
    ax[0].plot(trade["S"] / 1000, trade["E"] / 1000, "s-", color="#2e8b57", label="Battery energy (GWh)")
    ax[0].set_xlabel("Added PV, fixed (GW)")
    ax[0].set_ylabel("GW or GWh")
    twin = ax[0].twinx()
    twin.plot(trade["S"] / 1000, trade["capex_annual_m"], "^--", color="#c0504d", ms=3)
    twin.set_ylabel("Annualised cost (EUR m/yr)", color="#c0504d")
    twin.spines["right"].set_visible(True)
    ax[0].legend(fontsize=7, loc="upper center")
    ax[0].set_title("(a) PV–wind–storage trade-off at 95%")
    grid(ax[0])

    pairs = [("Capex ±30%", "capex-30", "capex+30"), ("Battery cost ±30%", "bess-30", "bess+30"),
             ("WACC 5% / 9%", "wacc5", "wacc9"), ("PV fleet anchor 3.0 / 4.0 GW", "pvcap3000", "pvcap4000")]
    for i, (label, a, b) in enumerate(pairs):
        lo, hi = sorted([sens[a], sens[b]])
        ax[1].barh(i, hi - lo, left=lo, color="#9ab8d4")
        ax[1].text(hi + 1, i, f"{sens[a]:.0f} / {sens[b]:.0f}", va="center", fontsize=7)
    ax[1].plot([sens["rte85"]], [4], "o", color="#1f3c5a")
    ax[1].text(sens["rte85"] + 2, 4, f"{sens['rte85']:.0f}", va="center", fontsize=7)
    ax[1].axvline(base, color="k", lw=1)
    ax[1].set_yticks(range(5))
    ax[1].set_yticklabels([p[0] for p in pairs] + ["Round-trip efficiency 85%"], fontsize=7.5)
    ax[1].set_xlabel("Cost per MWh replaced (EUR)")
    ax[1].set_title(f"(b) Sensitivity (base {base:.0f} EUR/MWh)")
    ax[1].set_xlim(80, 165)
    save("fig6_tradeoff_sensitivity.png")


def satellite_figure(H, dp):
    sat = pd.read_csv(DATA / "sarah3_SIS_hourly_romania_28jul_6aug2026.csv")
    sat["t"] = pd.to_datetime(sat["hour_start_local"].str[:19])
    sat = sat.set_index("t")
    start, end = "2026-07-29", "2026-08-06"
    window = sat[(sat.index >= start) & (sat.index < end)]
    battery = dp.set_index("t").reindex(window.index)

    fig = plt.figure(figsize=(9.4, 5.9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05])

    pv = H.set_index(pd.to_datetime(H["local"].astype(str).str[:19]))["solar"]
    joint = pd.DataFrame({"sis": sat["mean"], "pv": pv}).dropna()
    joint = joint[(joint.index >= "2026-08-01") & (joint.index < "2026-08-06") & (joint["sis"] > 100)]
    weekend = joint.index.dayofweek >= 5
    wd, we = joint[~weekend], joint[weekend]
    slope, icpt = np.polyfit(wd["sis"], wd["pv"], 1)

    a = fig.add_subplot(gs[0, 0])
    a.scatter(wd["sis"], wd["pv"] / 1000, s=10, color="#1f77b4", label="Weekdays 3-5 Aug")
    a.scatter(we["sis"], we["pv"] / 1000, s=10, marker="s", color="#c0504d", label="Weekend 1-2 Aug")
    xs = np.linspace(0, 950, 10)
    a.plot(xs, (slope * xs + icpt) / 1000, "k--", lw=1, label="Weekday fit")
    a.set_xlabel("National mean irradiance (W m$^{-2}$)")
    a.set_ylabel("Metered PV output (GW)")
    a.legend(fontsize=7)
    grid(a)
    a.set_title("(a) Metered PV against irradiance")

    b = fig.add_subplot(gs[0, 1])
    midday = window[(window.index.hour >= 11) & (window.index.hour < 16)]
    spread = midday.groupby(midday.index.date)[["p10", "p50", "p90"]].mean()
    xm = np.arange(len(spread))
    b.fill_between(xm, spread["p10"], spread["p90"], color="#f6c45f", alpha=0.5,
                   label="10th-90th percentile of grid cells")
    b.plot(xm, spread["p50"], "o-", color="#c77700", ms=3.5, label="Median")
    b.set_xticks(xm)
    b.set_xticklabels([pd.Timestamp(d).strftime("%a\n%d") for d in spread.index], fontsize=7.5)
    b.set_ylim(600, 900)
    b.set_ylabel("Irradiance 11:00-16:00 (W m$^{-2}$)")
    b.legend(fontsize=7, loc="lower left")
    grid(b)
    b.set_title("(b) Spatial spread of the midday resource")

    c = fig.add_subplot(gs[1, :])
    x = np.arange(len(window))
    for i, dark in enumerate(window["mean"].values < 50):
        if dark:
            c.axvspan(i - 0.5, i + 0.5, color="#e6e6ef", lw=0, zorder=0)
    c.plot(x, window["mean"].values, color="#f0a830", lw=1.6, label="National mean irradiance (SARAH-3)")
    c.set_ylim(0, 1000)
    c.set_ylabel("Irradiance (W m$^{-2}$)")
    twin = c.twinx()
    twin.bar(x, battery["d"].values, color="#2e8b57", width=1, label="Battery discharge, 95% portfolio")
    twin.bar(x, -battery["c"].values, color="#a9d8b8", width=1, label="Battery charging (negative)")
    twin.set_ylim(-2000, 2000)
    twin.set_ylabel("Battery (MW)")
    twin.spines["right"].set_visible(True)
    c.set_xticks(np.arange(0, len(x), 24))
    c.set_xticklabels([d.strftime("%a %d %b") for d in pd.date_range(start, periods=8)])
    c.set_xlim(-0.5, len(x) - 0.5)
    h1, l1 = c.get_legend_handles_labels()
    h2, l2 = twin.get_legend_handles_labels()
    c.legend(h1 + h2 + [mpatches.Patch(color="#e6e6ef")], l1 + l2 + ["Hours with irradiance below 50 W m$^{-2}$"],
             fontsize=6.8, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.13), frameon=False)
    c.set_title("(c) Solar resource and modelled battery operation, 29 July - 5 August 2026", pad=22)
    save("fig7_satellite.png", dpi=300)


def planner_figure(opt):
    B = pd.read_csv(RESULTS / "llm_planner_eval_all.csv")
    B["flag"] = B["flag"].fillna("")
    F = pd.read_csv(RESULTS / "frontier_coverage.csv")

    fig, ax = plt.subplots(1, 2, figsize=(10, 3.9), gridspec_kw=dict(width_ratios=[1, 1.25]))
    a = ax[0]
    shown = B[B["flag"] != "extreme"]
    a.plot([0] + list(100 * F["cov"]), [0] + list(F["cost_m"]), color=INK, lw=2, zorder=2,
           label="Least-cost frontier (LP)")
    for m in MODELS:
        for p in PROMPTS:
            g = shown[(shown["model"] == m) & (shown["prompt"] == p)]
            a.scatter(100 * g["coverage"], g["cost_annual_m"], s=26, marker=MARKER[p], color=MODEL_COLOR[m],
                      edgecolor="white", lw=0.6, alpha=0.9, zorder=3)
    a.scatter([95], [opt["capex_annual_m"]], s=170, marker="*", color=INK, edgecolor="white", zorder=4)
    a.annotate("95% optimum\n5.1 GW PV, 2.0 GW wind,\n1.5 GW / 13.1 GWh", (95, opt["capex_annual_m"]),
               xytext=(55, 760), fontsize=6.8, color=INK, arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    a.axvline(95, color=MUTED, ls="--", lw=1)
    a.text(94, 20, "target", rotation=90, fontsize=6.8, color=MUTED, ha="right", va="bottom")
    a.set_xlim(0, 100)
    a.set_ylim(0, 900)
    grid(a)
    a.set_xlabel("Share of lost nuclear energy replaced (%)")
    a.set_ylabel("Annualised cost (million EUR/yr)")
    a.set_title("(a) Cost and coverage of each proposal")
    handles = [Line2D([], [], color=INK, lw=2, label="Least-cost frontier")]
    handles += [Line2D([], [], marker=MARKER[p], ls="", color=MUTED, label=f"{PROMPT_LABEL[p]} prompt") for p in PROMPTS]
    a.legend(handles=handles, fontsize=6.6, loc="upper left", frameon=False)

    a = ax[1]
    x = 0
    ticks = []
    for m in MODELS:
        pos = []
        for p in PROMPTS:
            g = B[(B["model"] == m) & (B["prompt"] == p)]
            if g.empty:
                continue
            v = 100 * g["coverage"].values
            jitter = np.random.default_rng(int(10 * x)).uniform(-0.17, 0.17, len(v))
            a.scatter(x + jitter, v, s=16, marker=MARKER[p], color=MODEL_COLOR[m], edgecolor="white", lw=0.5,
                      alpha=0.9, zorder=3)
            a.plot([x - 0.28, x + 0.28], [np.median(v)] * 2, color=INK, lw=2, zorder=4, solid_capstyle="round")
            pos.append(x)
            x += 1
        ticks.append((np.mean(pos), MODEL_LABEL[m].replace(" ", "\n", 1)))
        x += 0.6
    a.axhline(95, color=MUTED, ls="--", lw=1)
    a.text(x - 0.7, 96.5, "target 95%", fontsize=6.8, color=MUTED, ha="right")
    a.set_xticks([t for t, _ in ticks])
    a.set_xticklabels([l for _, l in ticks], fontsize=7.4)
    a.set_ylim(0, 100)
    a.set_ylabel("Share of lost nuclear energy replaced (%)")
    grid(a, "y")
    a.set_title("(b) Coverage by model and prompt (bar = median)")
    handles = [Line2D([], [], marker="o", ls="", color=MODEL_COLOR[m], label=MODEL_LABEL[m]) for m in MODELS]
    fig.legend(handles=handles, loc="lower center", ncol=5, fontsize=7.2, frameon=False, bbox_to_anchor=(0.5, -0.04))
    plt.tight_layout(rect=(0, 0.05, 1, 1))
    plt.savefig(FIGURES / "fig8_llm_planner.png", bbox_inches="tight")
    plt.close()


def scenario_figure(opt):
    A = pd.concat([pd.read_csv(RESULTS / "llm_scenarios_eval.csv"),
                   pd.read_csv(RESULTS / "llm_scenarios_eval_v2.csv")], ignore_index=True)
    A = A[A["D_twh"] > 0.001]
    R = pd.read_csv(RESULTS / "random_scenarios_eval.csv")
    R = R[R["D_twh"] > 0.001]

    fig, ax = plt.subplots(1, 3, figsize=(11.5, 3.6), gridspec_kw=dict(width_ratios=[1.25, 1, 1]))
    a = ax[0]
    a.scatter(R["D_twh"], R["E"] / 1000, s=22, marker="x", color=MUTED, lw=1, label="Random baseline", zorder=2)
    for m in MODELS:
        g = A[A["model"] == m]
        a.scatter(g["D_twh"], g["E"] / 1000, s=22, color=MODEL_COLOR[m], edgecolor="white", lw=0.5, alpha=0.95,
                  label=MODEL_LABEL[m], zorder=3)
    a.scatter([opt["D_twh"]], [opt["E"] / 1000], s=170, marker="*", color=INK, edgecolor="white", zorder=4,
              label="2026 outage")
    a.set_xlabel("Replacement requirement, May–Sep (TWh)")
    a.set_ylabel("Battery energy for 95% coverage (GWh)")
    a.legend(fontsize=6.3, loc="upper left", frameon=False)
    grid(a)
    a.set_title("(a) Storage needed per scenario")

    a = ax[1]
    bins = np.arange(3, 12.5, 0.5)
    a.hist(A["dur"].dropna(), bins=bins, color="#2a78d6", alpha=0.75, edgecolor="white", lw=0.6,
           label=f"LLM scenarios (n={A['dur'].notna().sum()})")
    a.hist(R["dur"].dropna(), bins=bins, histtype="step", color=INK, lw=1.6,
           label=f"Random baseline (n={R['dur'].notna().sum()})")
    a.axvline(opt["dur"], color=MUTED, ls="--", lw=1)
    a.text(opt["dur"] - 0.15, a.get_ylim()[1] * 0.62, f"2026 outage\n{opt['dur']:.1f} h", fontsize=6.8, color=INK,
           ha="right")
    a.set_xlabel("Optimal battery duration (hours)")
    a.set_ylabel("Number of scenarios")
    a.legend(fontsize=6.5, loc="upper left", frameon=False)
    grid(a, "y")
    a.set_title("(b) Optimal storage duration")

    a = ax[2]
    features = [
        ("Nuclear\nreduction", lambda d: d["nuclear"] < 1219),
        ("Hydro\nincrease", lambda d: d["hydro"] > 0),
        ("Single\nmonth", lambda d: d["n_months"] == 1),
        ("Need above\n2026 (2.88 TWh)", lambda d: d["D_twh"] > 2.88),
    ]
    xx = np.arange(len(features))
    width = 0.36
    llm = [100 * f(A).mean() for _, f in features]
    rnd = [100 * f(R).mean() for _, f in features]
    a.bar(xx - width / 2 - 0.01, llm, width, color="#2a78d6", label="LLM scenarios")
    a.bar(xx + width / 2 + 0.01, rnd, width, color="white", edgecolor=INK, lw=1.2, label="Random baseline")
    for i in range(len(features)):
        a.text(xx[i] - width / 2, llm[i] + 1.5, f"{llm[i]:.0f}", ha="center", fontsize=6.8, color=INK)
        a.text(xx[i] + width / 2, rnd[i] + 1.5, f"{rnd[i]:.0f}", ha="center", fontsize=6.8, color=INK)
    a.set_xticks(xx)
    a.set_xticklabels([l for l, _ in features], fontsize=7)
    a.set_ylim(0, 110)
    a.set_ylabel("Share of scenarios (%)")
    a.legend(fontsize=6.5, loc="upper right", frameon=False)
    grid(a, "y")
    a.set_title("(c) What the scenarios contain")
    save("fig9_llm_scenarios.png")


if __name__ == "__main__":
    H = load_hourly()[0]
    res = pd.read_csv(RESULTS / "results.csv")
    opt = res[(res["tag"] == "A_nuclear") & (res["eps"] == 0.05)].iloc[0]
    dp = pd.read_csv(RESULTS / "dispatch_A05.csv")
    dp["t"] = pd.to_datetime(dp["local"].str[:19])

    system_figure(H)
    dispatch_figure(dp)
    frontier_figure()
    sensitivity_figure(res)
    satellite_figure(H, dp)
    planner_figure(opt)
    scenario_figure(opt)
    print("figures written to", FIGURES)

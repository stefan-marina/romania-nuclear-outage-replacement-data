import numpy as np
import pandas as pd

from settings import DATA, WIND_CAPACITY, PV_ANCHOR_MW, SITE_LATITUDE, PANEL_TILT, SEASON


def tilt_factor(month, lat=SITE_LATITUDE, tilt=PANEL_TILT):
    doy = pd.Timestamp(month + "-15").dayofyear
    declination = 23.44 * np.sin(2 * np.pi * (284 + doy) / 365)
    return np.cos(np.radians(lat - tilt - declination))


def load_hourly(anchor_mw=PV_ANCHOR_MW):
    df = pd.read_csv(DATA / "ro_hourly_2025_2026.csv", index_col=0, parse_dates=["local"])
    stamp = df["local"].astype(str)
    df["ym"] = stamp.str[:7]
    df["yr"] = df["ym"].str[:4]
    df["mon"] = df["ym"].str[5:7].astype(int)
    df["hour"] = stamp.str[11:13].astype(int)

    fleet = df.groupby("ym")["solar"].max().to_frame("max")
    fleet["rel"] = [tilt_factor(m) for m in fleet.index]
    kappa = fleet.loc["2026-04", "max"] / (anchor_mw * fleet.loc["2026-04", "rel"])
    fleet["cap"] = fleet["max"] / (kappa * fleet["rel"])

    df["pv_cap"] = df["ym"].map(fleet["cap"])
    df["s"] = (df["solar"] / df["pv_cap"]).clip(lower=0)
    df["w"] = (df["wind"] / df["yr"].map(WIND_CAPACITY)).clip(lower=0)
    return df, fleet, kappa


def season(df, year):
    lo, hi = SEASON
    return df[(df["yr"] == year) & df["mon"].between(lo, hi)].copy()

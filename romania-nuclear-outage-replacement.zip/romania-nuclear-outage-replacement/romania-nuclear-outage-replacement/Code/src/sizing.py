import json

import numpy as np
import pandas as pd

from lp import solve, annual_costs
from profiles import load_hourly, season
from settings import RESULTS, NUCLEAR_MW, EVENING


def summarise(r, tag, share, **extra):
    if r.get("status") != "ok":
        return dict(tag=tag, status=r.get("status"), **extra)
    period_cost = r["capex_annual"] * share
    served = r["D_pos"] - r["ext"]
    return dict(
        tag=tag, S=r["S"], W=r["W"], P=r["P"], E=r["E"],
        dur=r["E"] / r["P"] if r["P"] > 1 else np.nan,
        capex_annual_m=r["capex_annual"] / 1e6, capex_period_m=period_cost / 1e6,
        coverage=r["coverage"], served_twh=served / 1e6, D_twh=r["D_pos"] / 1e6,
        ext_twh=r["ext"] / 1e6, spill_twh=r["spill"] / 1e6,
        cost_per_mwh=period_cost / served if served > 0 else np.nan,
        ext_hours=r["ext_hours"], **extra,
    )


def scenarios(H, fleet, kappa):
    g26, g25 = season(H, "2026"), season(H, "2025")
    T = len(g26)
    share = T / 8760
    s, w = g26["s"].values, g26["w"].values
    lost = np.clip(NUCLEAR_MW - g26["nuclear"].values, 0, None)
    rows = []

    for eps in [0.5, 0.3, 0.2, 0.1, 0.05, 0.02, 0.01, 0.0]:
        rows.append(summarise(solve(lost, s, w, mode="energy", eps=eps), "A_nuclear", share, eps=eps, profile="2026"))
        rows.append(summarise(solve(lost, s, w, mode="energy", eps=eps, allow_wind=False),
                              "A_nuclear_PVonly", share, eps=eps, profile="2026"))

    flat = np.full(T, NUCLEAR_MW)
    for year, g in (("2025", g25), ("2026", g26)):
        for eps in [0.1, 0.05, 0.0]:
            r = solve(flat, g["s"].values, g["w"].values, mode="energy", eps=eps)
            rows.append(summarise(r, "D_const1219", share, eps=eps, profile=year))

    imports = g26["net_import"].values
    for cap in [2000, 1500, 1000, 500, 0]:
        rows.append(summarise(solve(imports, s, w, mode="hard", import_cap=cap), "B_importcap", share,
                              xcap=cap, profile="2026"))

    price = g26["price"].interpolate().values
    rows.append(summarise(solve(imports, s, w, mode="econ", price=price), "C_econ", share, profile="2026"))

    for pv in [2000, 3000, 4000, 5000, 6000, 8000, 10000]:
        r = solve(lost, s, w, mode="energy", eps=0.05, fix={"S": pv})
        rows.append(summarise(r, "E_tradeoff", share, eps=0.05, fixS=pv))

    cases = {
        "capex-30": dict(capex_mult=0.7), "capex+30": dict(capex_mult=1.3),
        "bess-30": dict(bess_mult=0.7), "bess+30": dict(bess_mult=1.3),
        "wacc5": dict(wacc=0.05), "wacc9": dict(wacc=0.09),
    }
    for name, kw in cases.items():
        r = solve(lost, s, w, mode="energy", eps=0.05, costs=annual_costs(**kw))
        rows.append(summarise(r, "F_sens", share, case=name))
    for anchor in [3000, 4000]:
        g = season(load_hourly(anchor)[0], "2026")
        r = solve(lost, g["s"].values, g["w"].values, mode="energy", eps=0.05)
        rows.append(summarise(r, "F_sens", share, case=f"pvcap{anchor}"))
    r = solve(lost, s, w, mode="energy", eps=0.05, rte=0.85)
    rows.append(summarise(r, "F_sens", share, case="rte85"))

    pd.DataFrame(rows).to_csv(RESULTS / "results.csv", index=False)

    r = solve(lost, s, w, mode="energy", eps=0.05)
    pd.DataFrame({
        "local": g26["local"].astype(str).values, "D": lost,
        "pv": r["S"] * s, "wind": r["W"] * w,
        "c": r["c"], "d": r["d"], "x": r["x"], "q": r["q"],
    }).to_csv(RESULTS / "dispatch_A05.csv", index=False)

    meta = dict(k0=kappa, pv_cap=fleet["cap"].round(0).to_dict(), costs=annual_costs())
    with open(RESULTS / "meta.json", "w") as fh:
        json.dump(meta, fh, indent=1)


def market_value(H):
    g = season(H, "2026")
    share = len(g) / 8760
    price = g["price"].interpolate().values
    imports = g["net_import"].values
    lost = np.clip(NUCLEAR_MW - g["nuclear"].values, 0, None)
    out = {}
    for name, need in (("C_econ_imports", imports), ("C_econ_nuclear", lost)):
        r = solve(need, g["s"].values, g["w"].values, mode="econ", price=price)
        pos = np.clip(need, 0, None)
        out[name] = dict(
            S=r["S"], W=r["W"], P=r["P"], E=r["E"], coverage=r["coverage"],
            capex_period_m=r["capex_annual"] * share / 1e6,
            avoided_cost_m=float((price * (pos - r["x"])).sum() / 1e6),
            base_cost_m=float((price * pos).sum() / 1e6),
        )
    pos_imports = np.clip(imports, 0, None)
    out["price_window_mean"] = float(np.nanmean(price))
    out["price_deficitweighted_A"] = float((price * lost).sum() / lost.sum())
    out["price_deficitweighted_B"] = float((price * pos_imports).sum() / pos_imports.sum())
    with open(RESULTS / "econ.json", "w") as fh:
        json.dump(out, fh, indent=1, default=float)


def net_cost(H):
    g = season(H, "2026")
    share = len(g) / 8760
    price = g["price"].interpolate().values
    lost = np.clip(NUCLEAR_MW - g["nuclear"].values, 0, None)
    rows = []
    for wind in (True, False):
        for eps in [0.5, 0.4, 0.3, 0.27, 0.2, 0.1, 0.05, 0.02, 0.01, 0.0]:
            r = solve(lost, g["s"].values, g["w"].values, mode="energy", eps=eps, allow_wind=wind)
            capex = r["capex_annual"] * share / 1e6
            avoided = float((price * (lost - r["x"])).sum() / 1e6)
            rows.append(dict(wind=wind, eps=eps, coverage=r["coverage"], capex_m=capex, avoided_m=avoided,
                             net_m=capex - avoided, S=r["S"], W=r["W"], P=r["P"], E=r["E"]))
    pd.DataFrame(rows).to_csv(RESULTS / "net_cost.csv", index=False)


def newey_west(X, y, lags=7):
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    u = y - X @ beta
    xu = X * u[:, None]
    meat = xu.T @ xu
    for lag in range(1, lags + 1):
        gamma = xu[lag:].T @ xu[:-lag]
        meat += (1 - lag / (lags + 1)) * (gamma + gamma.T)
    bread = np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(bread @ meat @ bread))
    r2 = 1 - (u @ u) / ((y - y.mean()) @ (y - y.mean()))
    return beta, se, r2


def describe(g):
    ni = g["net_import"]
    lo, hi = EVENING
    ev = g[g["hour"].between(lo, hi)]
    return dict(
        load=g["load"].mean(), net_import=ni.mean(), import_share_hours=100 * (ni > 0).mean(),
        import_twh=ni.clip(lower=0).sum() / 1e6, max_import=ni.max(), hours_gt1gw=int((ni > 1000).sum()),
        evening_import=ev["net_import"].mean(), nuclear=g["nuclear"].mean(), gas=g["gas"].mean(),
        lignite=g["lignite"].mean() + g["coal"].mean(), hydro=g["hydro_res"].mean() + g["hydro_ror"].mean(),
        solar=g["solar"].mean(), wind=g["wind"].mean(),
        vre_share=100 * (g["solar"].sum() + g["wind"].sum()) / g["load"].sum(),
        price=g["price"].mean(), evening_price=ev["price"].mean(),
        midday_price=g[g["hour"].between(11, 15)]["price"].mean(),
        neg_hours=int((g["price"] < 0).sum()), n=len(g),
    )


def indicators(H):
    out = {}
    for year in ("2025", "2026"):
        out[f"{year}_MaySep"] = describe(H[(H["yr"] == year) & H["mon"].between(5, 9)])
        out[f"{year}_JanApr"] = describe(H[(H["yr"] == year) & H["mon"].between(1, 4)])

    g = season(H, "2026")
    g["day"] = g["local"].astype(str).str[:10]
    cols = ["nuclear", "net_import", "gas", "hydro_res", "hydro_ror", "solar", "wind", "load"]
    daily = g.groupby("day")[cols].mean()
    X = np.c_[np.ones(len(daily)), NUCLEAR_MW - daily["nuclear"], daily["load"], daily["solar"] + daily["wind"]]

    out["reg"], out["reg_se"], out["reg_r2"] = {}, {}, {}
    for col in ("net_import", "gas", "hydro_res", "hydro_ror"):
        beta, se, r2 = newey_west(X, daily[col].values)
        out["reg"][col] = float(beta[1])
        out["reg_se"][col] = float(se[1])
        out["reg_r2"][col] = float(r2)
    out["reg_n"] = len(daily)

    with open(RESULTS / "indicators.json", "w") as fh:
        json.dump(out, fh, indent=1, default=float)


def flat_outage(H):
    rows = []
    for year in ("2025", "2026"):
        g = season(H, year)
        T = len(g)
        share = T / 8760
        price = g["price"].interpolate().values
        need = np.full(T, NUCLEAR_MW)
        for eps in [0.5, 0.3, 0.2, 0.1, 0.05, 0.0]:
            r = solve(need, g["s"].values, g["w"].values, mode="energy", eps=eps)
            capex = r["capex_annual"] * share / 1e6
            avoided = float((price * (need - r["x"])).sum() / 1e6)
            rows.append(dict(year=year, eps=eps, coverage=r["coverage"], capex_m=capex, avoided_m=avoided,
                             net_m=capex - avoided, S=r["S"], W=r["W"], P=r["P"], E=r["E"]))
        r = solve(need, g["s"].values, g["w"].values, mode="econ", price=price)
        rows.append(dict(year=year, eps="econ", coverage=r["coverage"], capex_m=r["capex_annual"] * share / 1e6,
                         avoided_m=float((price * (need - r["x"])).sum() / 1e6),
                         S=r["S"], W=r["W"], P=r["P"], E=r["E"]))
    df = pd.DataFrame(rows)
    df["net_m"] = df["capex_m"] - df["avoided_m"]
    df.to_csv(RESULTS / "const_weather_price.csv", index=False)


if __name__ == "__main__":
    H, fleet, kappa = load_hourly()
    indicators(H)
    scenarios(H, fleet, kappa)
    market_value(H)
    net_cost(H)
    flat_outage(H)
    print("results written to", RESULTS)
